import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import Chat from "@/pages/Chat";
import DiseaseDetection from "@/pages/DiseaseDetection";
import Weather from "@/pages/Weather";
import MarketPrices from "@/pages/MarketPrices";
import Advisory from "@/pages/Advisory";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Chat} />
      <Route path="/disease" component={DiseaseDetection} />
      <Route path="/weather" component={Weather} />
      <Route path="/market" component={MarketPrices} />
      <Route path="/advisory" component={Advisory} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <LanguageProvider>
          <TooltipProvider>
            <div className="min-h-screen bg-background text-foreground">
              <Header />
              <main className="pb-[3.5rem] md:pb-0">
                <Router />
              </main>
              <BottomNav />
            </div>
            <Toaster />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
