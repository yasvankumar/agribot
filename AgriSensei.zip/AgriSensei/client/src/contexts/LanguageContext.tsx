import { createContext, useContext, useState } from "react";

type Language = "en" | "ta";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translations
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    "nav.chat": "Chat",
    "nav.disease": "Disease Detection",
    "nav.weather": "Weather",
    "nav.market": "Market Prices",
    "nav.advisory": "Advisory",
    
    // Header
    "header.title": "AgriBot",
    "header.subtitle": "Your Smart Farming Assistant",
    
    // Chat
    "chat.title": "Chat with AgriBot",
    "chat.placeholder": "Ask me anything about farming...",
    "chat.send": "Send",
    "chat.upload": "Upload Image",
    "chat.empty.title": "Start a Conversation",
    "chat.empty.description": "Ask me about crop diseases, farming techniques, weather, or market prices.",
    "chat.suggestions.disease": "How do I identify crop diseases?",
    "chat.suggestions.weather": "What's the weather forecast?",
    "chat.suggestions.market": "Show me market prices",
    "chat.suggestions.irrigation": "Best irrigation practices?",
    
    // Disease Detection
    "disease.title": "Crop Disease Detection",
    "disease.upload": "Upload Crop Image",
    "disease.dropzone": "Drop image here or click to upload",
    "disease.analyzing": "Analyzing image...",
    "disease.confidence": "Confidence",
    "disease.severity": "Severity",
    "disease.treatment": "Treatment",
    "disease.prevention": "Prevention",
    "disease.symptoms": "Symptoms",
    
    // Weather
    "weather.title": "Weather Forecast",
    "weather.location": "Location",
    "weather.temperature": "Temperature",
    "weather.humidity": "Humidity",
    "weather.wind": "Wind Speed",
    "weather.rainfall": "Rainfall",
    "weather.forecast": "3-Day Forecast",
    
    // Market
    "market.title": "Market Prices",
    "market.crop": "Crop",
    "market.price": "Price",
    "market.trend": "Trend",
    "market.market": "Market",
    "market.updated": "Last Updated",
    "market.perQuintal": "per Quintal",
    
    // Advisory
    "advisory.title": "Farming Advisory",
    "advisory.cultivation": "Cultivation",
    "advisory.fertilizer": "Fertilizer",
    "advisory.pestControl": "Pest Control",
    "advisory.irrigation": "Irrigation",
    
    // Common
    "common.loading": "Loading...",
    "common.error": "Error",
    "common.retry": "Retry",
    "common.close": "Close",
    "common.view": "View Details",
    "common.language": "Language",
  },
  ta: {
    // Navigation
    "nav.chat": "அரட்டை",
    "nav.disease": "நோய் கண்டறிதல்",
    "nav.weather": "வானிலை",
    "nav.market": "சந்தை விலை",
    "nav.advisory": "ஆலோசனை",
    
    // Header
    "header.title": "அக்ரிபாட்",
    "header.subtitle": "உங்கள் ஸ்மார்ட் விவசாய உதவியாளர்",
    
    // Chat
    "chat.title": "அக்ரிபாட்டுடன் உரையாடுங்கள்",
    "chat.placeholder": "விவசாயம் பற்றி என்னிடம் கேளுங்கள்...",
    "chat.send": "அனுப்பு",
    "chat.upload": "படம் பதிவேற்று",
    "chat.empty.title": "உரையாடலைத் தொடங்குங்கள்",
    "chat.empty.description": "பயிர் நோய்கள், விவசாய நுட்பங்கள், வானிலை அல்லது சந்தை விலைகள் பற்றி என்னிடம் கேளுங்கள்.",
    "chat.suggestions.disease": "பயிர் நோய்களை எவ்வாறு கண்டறிவது?",
    "chat.suggestions.weather": "வானிலை முன்னறிவிப்பு என்ன?",
    "chat.suggestions.market": "சந்தை விலைகளைக் காட்டு",
    "chat.suggestions.irrigation": "சிறந்த நீர்ப்பாசன முறைகள்?",
    
    // Disease Detection
    "disease.title": "பயிர் நோய் கண்டறிதல்",
    "disease.upload": "பயிர் படத்தை பதிவேற்று",
    "disease.dropzone": "படத்தை இங்கே இழுத்து விடவும் அல்லது பதிவேற்ற கிளிக் செய்யவும்",
    "disease.analyzing": "படத்தை பகுப்பாய்வு செய்கிறது...",
    "disease.confidence": "நம்பிக்கை",
    "disease.severity": "தீவிரம்",
    "disease.treatment": "சிகிச்சை",
    "disease.prevention": "தடுப்பு",
    "disease.symptoms": "அறிகுறிகள்",
    
    // Weather
    "weather.title": "வானிலை முன்னறிவிப்பு",
    "weather.location": "இடம்",
    "weather.temperature": "வெப்பநிலை",
    "weather.humidity": "ஈரப்பதம்",
    "weather.wind": "காற்றின் வேகம்",
    "weather.rainfall": "மழைப்பொழிவு",
    "weather.forecast": "3 நாள் முன்னறிவிப்பு",
    
    // Market
    "market.title": "சந்தை விலைகள்",
    "market.crop": "பயிர்",
    "market.price": "விலை",
    "market.trend": "போக்கு",
    "market.market": "சந்தை",
    "market.updated": "கடைசியாக புதுப்பிக்கப்பட்டது",
    "market.perQuintal": "ஒரு குவிண்டால்",
    
    // Advisory
    "advisory.title": "விவசாய ஆலோசனை",
    "advisory.cultivation": "சாகுபடி",
    "advisory.fertilizer": "உரம்",
    "advisory.pestControl": "பூச்சி கட்டுப்பாடு",
    "advisory.irrigation": "நீர்ப்பாசனம்",
    
    // Common
    "common.loading": "ஏற்றுகிறது...",
    "common.error": "பிழை",
    "common.retry": "மீண்டும் முயற்சி செய்",
    "common.close": "மூடு",
    "common.view": "விவரங்களைக் காண்க",
    "common.language": "மொழி",
  },
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem("agribot-language");
    return (stored as Language) || "en";
  });

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem("agribot-language", lang);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
