import { useState } from "react";
import { Cloud, Droplets, Wind, MapPin, Loader2, CloudRain, Sun } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import type { WeatherData } from "@shared/schema";

interface ForecastDay {
  day: string;
  temp: number;
  condition: string;
}

export default function Weather() {
  const { t } = useLanguage();
  const [location, setLocation] = useState("Chennai, Tamil Nadu");
  const [searchLocation, setSearchLocation] = useState("");

  const { data: weather, isLoading, refetch } = useQuery<WeatherData & { forecast?: ForecastDay[] }>({
    queryKey: ["/api/weather", location],
    enabled: !!location,
  });

  const handleSearch = () => {
    if (searchLocation.trim()) {
      setLocation(searchLocation.trim());
      refetch();
    }
  };

  const getWeatherIcon = (condition: string) => {
    const lowerCondition = condition.toLowerCase();
    if (lowerCondition.includes("rain") || lowerCondition.includes("drizzle")) {
      return <CloudRain className="h-12 w-12 text-chart-2" />;
    } else if (lowerCondition.includes("cloud")) {
      return <Cloud className="h-12 w-12 text-muted-foreground" />;
    } else {
      return <Sun className="h-12 w-12 text-chart-4" />;
    }
  };

  const forecast: ForecastDay[] = weather?.forecast 
    ? JSON.parse(weather.forecast) 
    : [];

  return (
    <div className="min-h-[calc(100vh-4rem-3.5rem)] md:min-h-[calc(100vh-4rem)] p-4 md:p-6">
      <div className="mx-auto max-w-4xl space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-weather-title">
            {t("weather.title")}
          </h1>
          <p className="text-muted-foreground">
            Get accurate weather forecasts for your region
          </p>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-2">
              <Input
                placeholder={t("weather.location")}
                value={searchLocation}
                onChange={(e) => setSearchLocation(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                data-testid="input-weather-location"
              />
              <Button onClick={handleSearch} data-testid="button-search-weather">
                Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : weather ? (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  {weather.location}
                </CardTitle>
                <CardDescription>
                  Last updated: {new Date(weather.updatedAt).toLocaleString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="text-5xl font-bold" data-testid="text-temperature">
                      {weather.temperature}°C
                    </div>
                    <div className="text-xl text-muted-foreground mt-2" data-testid="text-condition">
                      {weather.condition}
                    </div>
                  </div>
                  {getWeatherIcon(weather.condition)}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {weather.humidity !== null && weather.humidity !== undefined && (
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-accent/50">
                      <Droplets className="h-8 w-8 text-chart-2" />
                      <div>
                        <div className="text-sm text-muted-foreground">
                          {t("weather.humidity")}
                        </div>
                        <div className="text-lg font-semibold" data-testid="text-humidity">
                          {weather.humidity}%
                        </div>
                      </div>
                    </div>
                  )}

                  {weather.windSpeed !== null && weather.windSpeed !== undefined && (
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-accent/50">
                      <Wind className="h-8 w-8 text-chart-1" />
                      <div>
                        <div className="text-sm text-muted-foreground">
                          {t("weather.wind")}
                        </div>
                        <div className="text-lg font-semibold" data-testid="text-wind">
                          {weather.windSpeed} km/h
                        </div>
                      </div>
                    </div>
                  )}

                  {weather.rainfall !== null && weather.rainfall !== undefined && (
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-accent/50">
                      <CloudRain className="h-8 w-8 text-chart-4" />
                      <div>
                        <div className="text-sm text-muted-foreground">
                          {t("weather.rainfall")}
                        </div>
                        <div className="text-lg font-semibold" data-testid="text-rainfall">
                          {weather.rainfall} mm
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {forecast.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>{t("weather.forecast")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {forecast.map((day, index) => (
                      <div
                        key={index}
                        className="text-center p-4 rounded-lg border hover-elevate"
                        data-testid={`card-forecast-${index}`}
                      >
                        <div className="text-sm font-medium mb-2">{day.day}</div>
                        <div className="flex justify-center mb-2">
                          {getWeatherIcon(day.condition)}
                        </div>
                        <div className="text-2xl font-bold">{day.temp}°C</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {day.condition}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        ) : null}
      </div>
    </div>
  );
}
