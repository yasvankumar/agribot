import { useState, useRef } from "react";
import { Upload, Loader2, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/contexts/LanguageContext";
import { useMutation } from "@tanstack/react-query";
import type { DiseaseDetection } from "@shared/schema";

export default function DiseaseDetection() {
  const { t, language } = useLanguage();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [result, setResult] = useState<DiseaseDetection | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const analyzeMutation = useMutation({
    mutationFn: async (data: { image: File; language: string }) => {
      const formData = new FormData();
      formData.append("image", data.image);
      formData.append("language", data.language);

      const response = await fetch("/api/disease/detect", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to analyze image");
      }

      return response.json();
    },
    onSuccess: (data: DiseaseDetection) => {
      setResult(data);
    },
  });

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      setResult(null);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = () => {
    if (selectedImage) {
      analyzeMutation.mutate({ image: selectedImage, language });
    }
  };

  const getSeverityColor = (severity?: string | null) => {
    switch (severity) {
      case "low":
        return "text-chart-3";
      case "moderate":
        return "text-chart-4";
      case "high":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };

  const getSeverityIcon = (severity?: string | null) => {
    switch (severity) {
      case "low":
        return <CheckCircle className="h-5 w-5" />;
      case "moderate":
        return <AlertCircle className="h-5 w-5" />;
      case "high":
        return <XCircle className="h-5 w-5" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem-3.5rem)] md:min-h-[calc(100vh-4rem)] p-4 md:p-6">
      <div className="mx-auto max-w-4xl space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-disease-title">
            {t("disease.title")}
          </h1>
          <p className="text-muted-foreground">
            Upload a photo of your crop to identify diseases instantly
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t("disease.upload")}</CardTitle>
            <CardDescription>{t("disease.dropzone")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={handleImageSelect}
            />

            {!imagePreview ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed rounded-lg p-12 text-center cursor-pointer hover-elevate"
                data-testid="dropzone-upload"
              >
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  PNG, JPG up to 10MB
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full rounded-lg border"
                    data-testid="img-preview"
                  />
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={() => {
                      setSelectedImage(null);
                      setImagePreview(null);
                      setResult(null);
                    }}
                    data-testid="button-remove-image"
                  >
                    Remove
                  </Button>
                </div>

                <Button
                  onClick={handleAnalyze}
                  disabled={analyzeMutation.isPending}
                  className="w-full"
                  data-testid="button-analyze"
                >
                  {analyzeMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("disease.analyzing")}
                    </>
                  ) : (
                    "Analyze Image"
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{result.diseaseName}</span>
                <div className={`flex items-center gap-2 ${getSeverityColor(result.severity)}`}>
                  {getSeverityIcon(result.severity)}
                  <span className="text-sm font-medium capitalize">
                    {result.severity || "Unknown"}
                  </span>
                </div>
              </CardTitle>
              <CardDescription>
                {result.cropType ? `Detected in ${result.cropType}` : ""}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">{t("disease.confidence")}</span>
                  <span className="text-sm font-bold">{result.confidence}%</span>
                </div>
                <Progress value={result.confidence} className="h-2" />
              </div>

              {result.symptoms && (
                <div>
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    {t("disease.symptoms")}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {result.symptoms}
                  </p>
                </div>
              )}

              {result.treatment && (
                <div>
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-chart-3" />
                    {t("disease.treatment")}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {result.treatment}
                  </p>
                </div>
              )}

              {result.prevention && (
                <div>
                  <h3 className="font-semibold mb-2">{t("disease.prevention")}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {result.prevention}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
