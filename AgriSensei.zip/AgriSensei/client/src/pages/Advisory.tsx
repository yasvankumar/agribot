import { BookOpen, Sprout, FlaskConical, Bug, Droplet } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import type { AdvisoryTip } from "@shared/schema";

const categoryIcons = {
  cultivation: Sprout,
  fertilizer: FlaskConical,
  "pest-control": Bug,
  irrigation: Droplet,
};

export default function Advisory() {
  const { t, language } = useLanguage();

  const { data: tips = [], isLoading } = useQuery<AdvisoryTip[]>({
    queryKey: ["/api/advisory", language],
  });

  const categories = ["cultivation", "fertilizer", "pest-control", "irrigation"] as const;

  const getTipsByCategory = (category: string) => {
    return tips.filter((tip) => tip.category === category);
  };

  return (
    <div className="min-h-[calc(100vh-4rem-3.5rem)] md:min-h-[calc(100vh-4rem)] p-4 md:p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2" data-testid="text-advisory-title">
            <BookOpen className="h-8 w-8" />
            {t("advisory.title")}
          </h1>
          <p className="text-muted-foreground">
            Expert farming tips and best practices
          </p>
        </div>

        <Tabs defaultValue="cultivation" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
            {categories.map((category) => {
              const Icon = categoryIcons[category];
              return (
                <TabsTrigger
                  key={category}
                  value={category}
                  className="flex items-center gap-2"
                  data-testid={`tab-${category}`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">
                    {t(`advisory.${category.replace("-", "")}`)}
                  </span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {categories.map((category) => {
            const categoryTips = getTipsByCategory(category);
            return (
              <TabsContent key={category} value={category} className="space-y-4 mt-6">
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Card key={i}>
                        <CardHeader>
                          <Skeleton className="h-6 w-3/4" />
                          <Skeleton className="h-4 w-1/2 mt-2" />
                        </CardHeader>
                        <CardContent>
                          <Skeleton className="h-20 w-full" />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : categoryTips.length === 0 ? (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <p className="text-muted-foreground">
                        No advisory tips available for this category
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {categoryTips.map((tip) => (
                      <Card
                        key={tip.id}
                        className="hover-elevate"
                        data-testid={`card-tip-${tip.id}`}
                      >
                        <CardHeader>
                          <CardTitle className="text-lg">{tip.title}</CardTitle>
                          <CardDescription className="flex gap-2 flex-wrap">
                            {tip.cropType && (
                              <Badge variant="outline" className="text-xs">
                                {tip.cropType}
                              </Badge>
                            )}
                            {tip.season && (
                              <Badge variant="outline" className="text-xs">
                                {tip.season}
                              </Badge>
                            )}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {tip.description}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </div>
  );
}
