import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import type { MarketPrice } from "@shared/schema";

export default function MarketPrices() {
  const { t } = useLanguage();

  const { data: prices = [], isLoading } = useQuery<MarketPrice[]>({
    queryKey: ["/api/market/prices"],
  });

  const getTrendIcon = (trend?: string | null) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-chart-3" />;
      case "down":
        return <TrendingDown className="h-4 w-4 text-destructive" />;
      default:
        return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getTrendColor = (trend?: string | null) => {
    switch (trend) {
      case "up":
        return "text-chart-3";
      case "down":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem-3.5rem)] md:min-h-[calc(100vh-4rem)] p-4 md:p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-market-title">
            {t("market.title")}
          </h1>
          <p className="text-muted-foreground">
            Real-time market prices for agricultural commodities
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-4 w-24 mt-2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : prices.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No market prices available</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {prices.map((price) => (
              <Card key={price.id} className="hover-elevate" data-testid={`card-price-${price.id}`}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span>{price.cropName}</span>
                    {getTrendIcon(price.trend)}
                  </CardTitle>
                  {price.variety && (
                    <CardDescription>{price.variety}</CardDescription>
                  )}
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold" data-testid={`text-price-${price.id}`}>
                        ₹{price.price}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        / {price.unit}
                      </span>
                    </div>
                    {price.previousPrice && (
                      <div className={`text-sm mt-1 ${getTrendColor(price.trend)}`}>
                        {price.trend === "up" ? "+" : "-"}₹
                        {Math.abs(price.price - price.previousPrice)} from last week
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {price.market && (
                      <Badge variant="outline" className="text-xs">
                        {price.market}
                      </Badge>
                    )}
                    {price.state && (
                      <Badge variant="outline" className="text-xs">
                        {price.state}
                      </Badge>
                    )}
                  </div>

                  <div className="text-xs text-muted-foreground">
                    {t("market.updated")}: {new Date(price.updatedAt).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
