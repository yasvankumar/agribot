# AgriBot - AI-Powered Smart Farming Assistant

## Overview
AgriBot is a bilingual (Tamil & English) AI-powered virtual assistant designed for farmers. It provides crop disease detection, farming advice, weather updates, and market prices through an accessible web interface.

## Recent Changes
- **October 19, 2025**: Initial MVP implementation
  - Created comprehensive data schemas for conversations, messages, disease detection, weather, market prices, and advisory tips
  - Built complete bilingual UI with Tamil and English support
  - Implemented all major pages: Chat, Disease Detection, Weather, Market Prices, Advisory
  - Created theme toggle (light/dark mode) and language switcher
  - Designed mobile-first responsive interface with bottom navigation
  - Configured agricultural-themed color palette with earthy greens

## User Preferences
- Target Users: Farmers in rural India, particularly Tamil Nadu region
- Language Support: English and Tamil (தமிழ்)
- Design: Clean, accessible interface optimized for mobile devices and low bandwidth
- Color Scheme: Agricultural theme with earthy greens (primary: 130 45% 45%)

## Project Architecture

### Technology Stack
- **Frontend**: React + TypeScript, Wouter (routing), TanStack Query (data fetching)
- **Backend**: Express.js, Node.js
- **AI**: OpenAI GPT-5 for conversational AI and vision-based disease detection
- **Storage**: In-memory storage (MemStorage) for development
- **UI**: Shadcn UI components, Tailwind CSS
- **Fonts**: Inter (excellent Tamil script support)

### Data Models
1. **Conversations**: Chat sessions with language preference
2. **Messages**: Individual chat messages with role (user/assistant) and optional images
3. **Disease Detections**: Crop disease analysis results with treatment recommendations
4. **Weather Data**: Location-based weather information with forecasts
5. **Market Prices**: Agricultural commodity prices with trends
6. **Advisory Tips**: Farming tips categorized by type (cultivation, fertilizer, pest control, irrigation)

### Features Implemented
1. **Chat Interface**
   - Bilingual conversational AI powered by OpenAI GPT-5
   - Image upload support for crop disease queries
   - Message history with timestamps
   - Quick suggestion chips for common queries

2. **Disease Detection**
   - Image upload with drag-and-drop
   - AI-powered disease identification using vision models
   - Confidence scores and severity indicators
   - Treatment and prevention recommendations

3. **Weather Forecast**
   - Location-based weather lookup
   - Current conditions with temperature, humidity, wind speed, rainfall
   - 3-day forecast visualization
   - Weather icons based on conditions

4. **Market Prices**
   - Real-time commodity prices
   - Trend indicators (up/down/stable)
   - Market and state information
   - Price comparison with previous week

5. **Advisory Hub**
   - Categorized farming tips (cultivation, fertilizer, pest control, irrigation)
   - Crop-specific and season-specific advice
   - Bilingual content support
   - Tab-based navigation

### API Endpoints (To Be Implemented)
- `GET /api/conversation/active` - Get or create active conversation
- `GET /api/messages/:conversationId` - Fetch messages for a conversation
- `POST /api/chat` - Send message and get AI response
- `POST /api/disease/detect` - Analyze crop image for disease detection
- `GET /api/weather/:location` - Get weather data for location
- `GET /api/market/prices` - Get current market prices
- `GET /api/advisory/:language` - Get advisory tips in specified language

### File Structure
```
client/
  src/
    components/
      ui/ - Shadcn UI components
      Header.tsx - App header with branding and toggles
      BottomNav.tsx - Mobile bottom navigation
    contexts/
      ThemeContext.tsx - Light/dark mode management
      LanguageContext.tsx - Tamil/English translation system
    pages/
      Chat.tsx - Main chat interface
      DiseaseDetection.tsx - Image-based disease detection
      Weather.tsx - Weather forecast viewer
      MarketPrices.tsx - Market price listings
      Advisory.tsx - Farming advisory tips
    App.tsx - Main app with routing
    
server/
  routes.ts - API endpoint definitions (to be implemented)
  storage.ts - In-memory storage interface
  
shared/
  schema.ts - Shared TypeScript types and Zod schemas
```

## Next Steps
1. Implement backend API routes with OpenAI integration
2. Add weather API integration (OpenWeather)
3. Create mock market price data
4. Implement advisory tips database
5. Add image upload handling with Multer
6. Test all features end-to-end
7. Future: WhatsApp bot integration, custom ML models for disease detection

## Environment Variables
- `OPENAI_API_KEY` - OpenAI API key for GPT-5 and vision models
- `SESSION_SECRET` - Session management secret
