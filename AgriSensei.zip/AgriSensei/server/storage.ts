import { randomUUID } from "crypto";
import type {
  Conversation, InsertConversation,
  Message, InsertMessage,
  DiseaseDetection, InsertDiseaseDetection,
  WeatherData, InsertWeatherData,
  MarketPrice, InsertMarketPrice,
  AdvisoryTip, InsertAdvisoryTip,
} from "@shared/schema";

export interface IStorage {
  // Conversations
  getActiveConversation(): Promise<Conversation | undefined>;
  createConversation(data: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, data: Partial<Conversation>): Promise<Conversation>;

  // Messages
  getMessagesByConversation(conversationId: string): Promise<Message[]>;
  createMessage(data: InsertMessage): Promise<Message>;

  // Disease Detection
  createDiseaseDetection(data: InsertDiseaseDetection): Promise<DiseaseDetection>;
  getDiseaseDetections(): Promise<DiseaseDetection[]>;

  // Weather
  getWeatherByLocation(location: string): Promise<WeatherData | undefined>;
  createOrUpdateWeather(data: InsertWeatherData): Promise<WeatherData>;

  // Market Prices
  getMarketPrices(): Promise<MarketPrice[]>;
  createMarketPrice(data: InsertMarketPrice): Promise<MarketPrice>;

  // Advisory Tips
  getAdvisoryTips(language?: string): Promise<AdvisoryTip[]>;
  createAdvisoryTip(data: InsertAdvisoryTip): Promise<AdvisoryTip>;
}

export class MemStorage implements IStorage {
  private conversations: Map<string, Conversation>;
  private messages: Map<string, Message>;
  private diseaseDetections: Map<string, DiseaseDetection>;
  private weatherData: Map<string, WeatherData>;
  private marketPrices: Map<string, MarketPrice>;
  private advisoryTips: Map<string, AdvisoryTip>;

  constructor() {
    this.conversations = new Map();
    this.messages = new Map();
    this.diseaseDetections = new Map();
    this.weatherData = new Map();
    this.marketPrices = new Map();
    this.advisoryTips = new Map();

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample market prices
    const samplePrices: InsertMarketPrice[] = [
      {
        cropName: "Rice (Paddy)",
        variety: "IR-64",
        price: 2800,
        unit: "quintal",
        market: "Chennai Mandi",
        state: "Tamil Nadu",
        trend: "up",
        previousPrice: 2650,
      },
      {
        cropName: "Wheat",
        variety: "PBW-343",
        price: 2200,
        unit: "quintal",
        market: "Coimbatore Market",
        state: "Tamil Nadu",
        trend: "stable",
        previousPrice: 2200,
      },
      {
        cropName: "Sugarcane",
        price: 3100,
        unit: "ton",
        market: "Erode Market",
        state: "Tamil Nadu",
        trend: "down",
        previousPrice: 3300,
      },
      {
        cropName: "Cotton",
        variety: "MCU-5",
        price: 6500,
        unit: "quintal",
        market: "Madurai Mandi",
        state: "Tamil Nadu",
        trend: "up",
        previousPrice: 6200,
      },
      {
        cropName: "Groundnut",
        price: 5800,
        unit: "quintal",
        market: "Salem Market",
        state: "Tamil Nadu",
        trend: "up",
        previousPrice: 5500,
      },
      {
        cropName: "Tomato",
        price: 1200,
        unit: "quintal",
        market: "Koyambedu Market",
        state: "Tamil Nadu",
        trend: "down",
        previousPrice: 1500,
      },
    ];

    samplePrices.forEach((price) => {
      this.createMarketPrice({
        ...price,
        variety: price.variety ?? null,
        trend: price.trend ?? null,
        previousPrice: price.previousPrice ?? null,
      });
    });

    // Sample advisory tips - English
    const sampleAdvisoryEn: InsertAdvisoryTip[] = [
      {
        category: "cultivation",
        title: "Rice Transplanting Best Practices",
        description: "For optimal rice yields, transplant seedlings at 21-25 days old with 2-3 seedlings per hill. Maintain 20x15 cm spacing between rows and plants. Ensure field has 2-3 cm standing water during transplanting.",
        cropType: "Rice",
        season: "Kharif",
        language: "en",
      },
      {
        category: "fertilizer",
        title: "Balanced NPK Application for Cotton",
        description: "Apply 120:60:60 kg/ha NPK for cotton. Give nitrogen in 3 splits: 25% basal, 50% at square formation, 25% at flowering. Apply full phosphorus and potash as basal dose.",
        cropType: "Cotton",
        language: "en",
      },
      {
        category: "pest-control",
        title: "Integrated Pest Management for Tomato",
        description: "Use yellow sticky traps to monitor whitefly population. Spray neem oil (3 ml/liter) at 15-day intervals. Install pheromone traps @ 5/acre for fruit borer. Remove and destroy affected fruits immediately.",
        cropType: "Tomato",
        language: "en",
      },
      {
        category: "irrigation",
        title: "Drip Irrigation for Sugarcane",
        description: "Install drip system with 60 cm lateral spacing. Irrigate at 0.8 IW/CPE ratio. Apply 2500-3000 liters per day during formative phase, reduce to 1500-2000 liters during maturity. Save up to 40% water compared to flood irrigation.",
        cropType: "Sugarcane",
        language: "en",
      },
      {
        category: "cultivation",
        title: "Groundnut Seed Treatment",
        description: "Treat seeds with Trichoderma @ 4g/kg seeds before sowing. This controls soil-borne diseases and improves germination by 10-15%. Apply rhizobium culture for better nitrogen fixation and higher yields.",
        cropType: "Groundnut",
        season: "Rabi",
        language: "en",
      },
      {
        category: "fertilizer",
        title: "Organic Manure Application",
        description: "Apply well-decomposed FYM or compost @ 10-12 tons/ha 15-20 days before sowing. Enriches soil organic matter, improves water retention, and provides slow-release nutrients. Can reduce chemical fertilizer use by 25%.",
        language: "en",
      },
    ];

    sampleAdvisoryEn.forEach((tip) => {
      this.createAdvisoryTip({
        ...tip,
        cropType: tip.cropType ?? null,
        season: tip.season ?? null,
      });
    });

    // Sample advisory tips - Tamil
    const sampleAdvisoryTa: InsertAdvisoryTip[] = [
      {
        category: "cultivation",
        title: "நெல் நாற்று நடவு சிறந்த நடைமுறைகள்",
        description: "உகந்த நெல் விளைச்சலுக்கு, 21-25 நாட்கள் வயதான நாற்றுகளை ஒரு குழிக்கு 2-3 நாற்றுகள் கொண்டு நடவு செய்யவும். வரிசைகள் மற்றும் செடிகளுக்கு இடையே 20x15 செ.மீ இடைவெளி வைக்கவும். நடவின்போது வயலில் 2-3 செ.மீ தண்ணீர் இருக்க வேண்டும்.",
        cropType: "நெல்",
        season: "கரீஃப்",
        language: "ta",
      },
      {
        category: "fertilizer",
        title: "பருத்திக்கான சமச்சீர் NPK பயன்பாடு",
        description: "பருத்திக்கு 120:60:60 கிலோ/ஹெக்டேர் NPK இடவும். நைட்ரஜனை 3 பகுதிகளாக: 25% அடியுரமாக, 50% சதுர உருவாக்கத்தில், 25% பூக்கும்போது இடவும். முழு பாஸ்பரஸ் மற்றும் பொட்டாஷையும் அடியுரமாக இடவும்.",
        cropType: "பருத்தி",
        language: "ta",
      },
      {
        category: "pest-control",
        title: "தக்காளிக்கான ஒருங்கிணைந்த பூச்சி மேலாண்மை",
        description: "வெள்ளை ஈ எண்ணிக்கையை கண்காணிக்க மஞ்சள் ஒட்டும் பொறிகளை பயன்படுத்தவும். 15 நாள் இடைவெளியில் வேப்ப எண்ணெய் (3 மி.லி/லிட்டர்) தெளிக்கவும். பழ துளைப்பானுக்கு ஃபெரமோன் பொறிகளை @ 5/ஏக்கர் நிறுவவும். பாதிக்கப்பட்ட பழங்களை உடனே அகற்றி அழிக்கவும்.",
        cropType: "தக்காளி",
        language: "ta",
      },
      {
        category: "irrigation",
        title: "கரும்புக்கான சொட்டு நீர்ப்பாசனம்",
        description: "60 செ.மீ பக்கவாட்டு இடைவெளியுடன் சொட்டு அமைப்பை நிறுவவும். 0.8 IW/CPE விகிதத்தில் நீர்ப்பாசனம் செய்யவும். உருவாக்க கட்டத்தில் நாளொன்றுக்கு 2500-3000 லிட்டர், முதிர்ச்சியின்போது 1500-2000 லிட்டராக குறைக்கவும். வெள்ள நீர்ப்பாசனத்துடன் ஒப்பிடும்போது 40% தண்ணீர் சேமிக்கலாம்.",
        cropType: "கரும்பு",
        language: "ta",
      },
    ];

    sampleAdvisoryTa.forEach((tip) => {
      this.createAdvisoryTip({
        ...tip,
        cropType: tip.cropType ?? null,
        season: tip.season ?? null,
      });
    });
  }

  // Conversations
  async getActiveConversation(): Promise<Conversation | undefined> {
    const conversations = Array.from(this.conversations.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    return conversations[0];
  }

  async createConversation(data: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const now = new Date();
    const conversation: Conversation = {
      id,
      title: data.title,
      language: data.language ?? "en",
      createdAt: now,
      updatedAt: now,
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: string, data: Partial<Conversation>): Promise<Conversation> {
    const existing = this.conversations.get(id);
    if (!existing) {
      throw new Error("Conversation not found");
    }
    const updated: Conversation = {
      ...existing,
      ...data,
      id,
      updatedAt: new Date(),
    };
    this.conversations.set(id, updated);
    return updated;
  }

  // Messages
  async getMessagesByConversation(conversationId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((msg) => msg.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async createMessage(data: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      id,
      conversationId: data.conversationId,
      role: data.role,
      content: data.content,
      imageUrl: data.imageUrl ?? null,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  // Disease Detection
  async createDiseaseDetection(data: InsertDiseaseDetection): Promise<DiseaseDetection> {
    const id = randomUUID();
    const detection: DiseaseDetection = {
      id,
      imageUrl: data.imageUrl,
      diseaseName: data.diseaseName,
      confidence: data.confidence,
      cropType: data.cropType ?? null,
      symptoms: data.symptoms ?? null,
      treatment: data.treatment ?? null,
      prevention: data.prevention ?? null,
      severity: data.severity ?? null,
      createdAt: new Date(),
    };
    this.diseaseDetections.set(id, detection);
    return detection;
  }

  async getDiseaseDetections(): Promise<DiseaseDetection[]> {
    return Array.from(this.diseaseDetections.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Weather
  async getWeatherByLocation(location: string): Promise<WeatherData | undefined> {
    return Array.from(this.weatherData.values()).find(
      (w) => w.location.toLowerCase() === location.toLowerCase()
    );
  }

  async createOrUpdateWeather(data: InsertWeatherData): Promise<WeatherData> {
    const existing = await this.getWeatherByLocation(data.location);
    if (existing) {
      const updated: WeatherData = {
        ...existing,
        ...data,
        updatedAt: new Date(),
      };
      this.weatherData.set(existing.id, updated);
      return updated;
    }

    const id = randomUUID();
    const weather: WeatherData = {
      id,
      location: data.location,
      temperature: data.temperature,
      condition: data.condition,
      humidity: data.humidity ?? null,
      windSpeed: data.windSpeed ?? null,
      rainfall: data.rainfall ?? null,
      forecast: data.forecast ?? null,
      updatedAt: new Date(),
    };
    this.weatherData.set(id, weather);
    return weather;
  }

  // Market Prices
  async getMarketPrices(): Promise<MarketPrice[]> {
    return Array.from(this.marketPrices.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async createMarketPrice(data: InsertMarketPrice): Promise<MarketPrice> {
    const id = randomUUID();
    const price: MarketPrice = {
      id,
      cropName: data.cropName,
      variety: data.variety ?? null,
      price: data.price,
      unit: data.unit ?? "quintal",
      market: data.market,
      state: data.state,
      trend: data.trend ?? null,
      previousPrice: data.previousPrice ?? null,
      updatedAt: new Date(),
    };
    this.marketPrices.set(id, price);
    return price;
  }

  // Advisory Tips
  async getAdvisoryTips(language?: string): Promise<AdvisoryTip[]> {
    let tips = Array.from(this.advisoryTips.values());
    if (language) {
      tips = tips.filter((tip) => tip.language === language);
    }
    return tips.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createAdvisoryTip(data: InsertAdvisoryTip): Promise<AdvisoryTip> {
    const id = randomUUID();
    const tip: AdvisoryTip = {
      id,
      category: data.category,
      title: data.title,
      description: data.description,
      cropType: data.cropType ?? null,
      season: data.season ?? null,
      language: data.language ?? "en",
      createdAt: new Date(),
    };
    this.advisoryTips.set(id, tip);
    return tip;
  }
}

export const storage = new MemStorage();
