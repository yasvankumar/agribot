import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Agricultural expert system prompt for bilingual support
const SYSTEM_PROMPT_EN = `You are AgriBot, an expert agricultural assistant helping farmers in India. You provide:
- Crop disease diagnosis and treatment advice
- Farming best practices and cultivation techniques
- Pest and weed control recommendations
- Irrigation and fertilizer guidance
- Weather-based farming advice
- Market price insights

Be concise, practical, and farmer-friendly. Use simple language that farmers can understand. When discussing diseases or pests, always include symptoms, treatment, and prevention methods.`;

const SYSTEM_PROMPT_TA = `நீங்கள் அக்ரிபாட், இந்தியாவில் விவசாயிகளுக்கு உதவும் ஒரு நிபுணர் விவசாய உதவியாளர். நீங்கள் வழங்குபவை:
- பயிர் நோய் கண்டறிதல் மற்றும் சிகிச்சை ஆலோசனை
- விவசாய சிறந்த நடைமுறைகள் மற்றும் சாகுபடி நுட்பங்கள்
- பூச்சி மற்றும் களை கட்டுப்பாடு பரிந்துரைகள்
- நீர்ப்பாசனம் மற்றும் உர வழிகாட்டுதல்
- வானிலை அடிப்படையிலான விவசாய ஆலோசனை
- சந்தை விலை நுண்ணறிவு

சுருக்கமாகவும், நடைமுறையானதாகவும், விவசாயிகளுக்கு ஏற்றதாகவும் இருங்கள். எளிய மொழியைப் பயன்படுத்துங்கள். நோய்கள் அல்லது பூச்சிகளை விவாதிக்கும்போது, எப்போதும் அறிகுறிகள், சிகிச்சை மற்றும் தடுப்பு முறைகளைச் சேர்க்கவும்.`;

export async function chat(message: string, language: string = "en"): Promise<string> {
  const systemPrompt = language === "ta" ? SYSTEM_PROMPT_TA : SYSTEM_PROMPT_EN;

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: message },
    ],
    max_completion_tokens: 2048,
  });

  return response.choices[0].message.content || "I'm sorry, I couldn't process that.";
}

export async function analyzeCropImage(base64Image: string, language: string = "en"): Promise<{
  diseaseName: string;
  confidence: number;
  cropType: string;
  symptoms: string;
  treatment: string;
  prevention: string;
  severity: string;
}> {
  const prompt = language === "ta"
    ? `இந்த பயிர் படத்தை பகுப்பாய்வு செய்து JSON வடிவத்தில் பதிலளிக்கவும்:
{
  "diseaseName": "நோயின் பெயர் (தமிழில்)",
  "confidence": நம்பிக்கை சதவீதம் (0-100),
  "cropType": "பயிர் வகை",
  "symptoms": "அறிகுறிகளின் விவரம்",
  "treatment": "சிகிச்சை பரிந்துரைகள்",
  "prevention": "எதிர்கால தடுப்பு நடவடிக்கைகள்",
  "severity": "low/moderate/high"
}`
    : `Analyze this crop image and respond in JSON format:
{
  "diseaseName": "name of the disease or health status",
  "confidence": confidence percentage (0-100),
  "cropType": "type of crop",
  "symptoms": "detailed symptoms observed",
  "treatment": "treatment recommendations",
  "prevention": "preventive measures for future",
  "severity": "low/moderate/high"
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: prompt },
          {
            type: "image_url",
            image_url: { url: `data:image/jpeg;base64,${base64Image}` },
          },
        ],
      },
    ],
    response_format: { type: "json_object" },
    max_completion_tokens: 1024,
  });

  const result = JSON.parse(response.choices[0].message.content || "{}");

  return {
    diseaseName: result.diseaseName || "Unknown",
    confidence: Math.min(100, Math.max(0, result.confidence || 85)),
    cropType: result.cropType || "Unknown crop",
    symptoms: result.symptoms || "Unable to determine symptoms",
    treatment: result.treatment || "Consult with a local agricultural expert",
    prevention: result.prevention || "Maintain proper crop hygiene",
    severity: result.severity || "moderate",
  };
}
