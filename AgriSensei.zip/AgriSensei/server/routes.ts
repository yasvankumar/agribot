import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { chat, analyzeCropImage } from "./openai";
import { insertMessageSchema, insertDiseaseDetectionSchema } from "@shared/schema";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get or create active conversation
  app.get("/api/conversation/active", async (req, res) => {
    try {
      let conversation = await storage.getActiveConversation();
      
      if (!conversation) {
        conversation = await storage.createConversation({
          title: "New Chat",
          language: "en",
        });
      }
      
      res.json(conversation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get messages for a conversation
  app.get("/api/messages/:conversationId", async (req, res) => {
    try {
      const messages = await storage.getMessagesByConversation(req.params.conversationId);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Send chat message
  app.post("/api/chat", upload.single("image"), async (req, res) => {
    try {
      const { message, language } = req.body;
      const imageFile = req.file;
      const userLanguage = language || "en";

      // Get or create conversation
      let conversation = await storage.getActiveConversation();
      if (!conversation) {
        conversation = await storage.createConversation({
          title: message.substring(0, 50),
          language: userLanguage,
        });
      } else if (conversation.language !== userLanguage) {
        // Update conversation language if user switched
        conversation = await storage.updateConversation(conversation.id, {
          language: userLanguage,
        });
      }

      // Create user message
      let userImageUrl: string | undefined;
      if (imageFile) {
        const base64Image = imageFile.buffer.toString("base64");
        userImageUrl = `data:${imageFile.mimetype};base64,${base64Image}`;
      }

      await storage.createMessage({
        conversationId: conversation.id,
        role: "user",
        content: message || "Please analyze this image",
        imageUrl: userImageUrl,
      });

      // Generate AI response
      let aiResponse: string;
      
      if (imageFile) {
        const base64Image = imageFile.buffer.toString("base64");
        const analysisResult = await analyzeCropImage(base64Image, conversation.language);
        
        // Format the response
        if (conversation.language === "ta") {
          aiResponse = `நோய் கண்டறிதல்: ${analysisResult.diseaseName}\n\nபயிர்: ${analysisResult.cropType}\nநம்பிக்கை: ${analysisResult.confidence}%\nதீவிரம்: ${analysisResult.severity}\n\nஅறிகுறிகள்:\n${analysisResult.symptoms}\n\nசிகிச்சை:\n${analysisResult.treatment}\n\nதடுப்பு:\n${analysisResult.prevention}`;
        } else {
          aiResponse = `Disease Detection: ${analysisResult.diseaseName}\n\nCrop: ${analysisResult.cropType}\nConfidence: ${analysisResult.confidence}%\nSeverity: ${analysisResult.severity}\n\nSymptoms:\n${analysisResult.symptoms}\n\nTreatment:\n${analysisResult.treatment}\n\nPrevention:\n${analysisResult.prevention}`;
        }
      } else {
        aiResponse = await chat(message, conversation.language);
      }

      // Create assistant message
      const assistantMessage = await storage.createMessage({
        conversationId: conversation.id,
        role: "assistant",
        content: aiResponse,
      });

      // Update conversation timestamp
      await storage.updateConversation(conversation.id, {
        updatedAt: new Date(),
      });

      res.json({ success: true, message: assistantMessage });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Disease detection endpoint
  app.post("/api/disease/detect", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No image provided" });
      }

      const base64Image = req.file.buffer.toString("base64");
      const imageUrl = `data:${req.file.mimetype};base64,${base64Image}`;
      const language = req.body.language || "en";

      // Get analysis result in requested language
      const analysisResult = await analyzeCropImage(base64Image, language);

      const detection = await storage.createDiseaseDetection({
        imageUrl,
        diseaseName: analysisResult.diseaseName,
        confidence: analysisResult.confidence,
        cropType: analysisResult.cropType || null,
        symptoms: analysisResult.symptoms || null,
        treatment: analysisResult.treatment || null,
        prevention: analysisResult.prevention || null,
        severity: analysisResult.severity || null,
      });

      res.json(detection);
    } catch (error: any) {
      console.error("Disease detection error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Weather endpoint
  app.get("/api/weather/:location", async (req, res) => {
    try {
      const location = decodeURIComponent(req.params.location);
      
      // Check if we have recent weather data (within 1 hour)
      let weatherData = await storage.getWeatherByLocation(location);
      const now = new Date();
      
      if (weatherData) {
        const age = now.getTime() - new Date(weatherData.updatedAt).getTime();
        if (age < 3600000) { // 1 hour in milliseconds
          return res.json(weatherData);
        }
      }

      // Generate mock weather data for demonstration
      // In production, this would call a real weather API
      const conditions = ["Clear", "Partly Cloudy", "Cloudy", "Light Rain", "Heavy Rain"];
      const condition = conditions[Math.floor(Math.random() * conditions.length)];
      
      const forecast = [
        { day: "Tomorrow", temp: 28 + Math.floor(Math.random() * 8), condition: "Partly Cloudy" },
        { day: "Day 2", temp: 27 + Math.floor(Math.random() * 8), condition: "Clear" },
        { day: "Day 3", temp: 26 + Math.floor(Math.random() * 8), condition: "Light Rain" },
      ];

      weatherData = await storage.createOrUpdateWeather({
        location,
        temperature: 25 + Math.floor(Math.random() * 15),
        condition,
        humidity: 60 + Math.floor(Math.random() * 30),
        windSpeed: 10 + Math.floor(Math.random() * 20),
        rainfall: condition.includes("Rain") ? Math.floor(Math.random() * 50) : 0,
        forecast: JSON.stringify(forecast),
      });

      res.json(weatherData);
    } catch (error: any) {
      console.error("Weather error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Market prices endpoint
  app.get("/api/market/prices", async (req, res) => {
    try {
      const prices = await storage.getMarketPrices();
      res.json(prices);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Advisory tips endpoint
  app.get("/api/advisory/:language", async (req, res) => {
    try {
      const language = req.params.language === "ta" ? "ta" : "en";
      const tips = await storage.getAdvisoryTips(language);
      res.json(tips);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
