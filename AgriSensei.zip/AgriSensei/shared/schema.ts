import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Chat Conversations
export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  language: varchar("language", { length: 10 }).notNull().default("en"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// Chat Messages
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull(),
  role: varchar("role", { length: 20 }).notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Disease Detection Results
export const diseaseDetections = pgTable("disease_detections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  imageUrl: text("image_url").notNull(),
  diseaseName: text("disease_name").notNull(),
  confidence: integer("confidence").notNull(), // 0-100
  cropType: text("crop_type"),
  symptoms: text("symptoms"),
  treatment: text("treatment"),
  prevention: text("prevention"),
  severity: varchar("severity", { length: 20 }), // 'low', 'moderate', 'high'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertDiseaseDetectionSchema = createInsertSchema(diseaseDetections).omit({
  id: true,
  createdAt: true,
});

export type InsertDiseaseDetection = z.infer<typeof insertDiseaseDetectionSchema>;
export type DiseaseDetection = typeof diseaseDetections.$inferSelect;

// Weather Data (stored for caching)
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  temperature: integer("temperature").notNull(),
  condition: text("condition").notNull(),
  humidity: integer("humidity"),
  windSpeed: integer("wind_speed"),
  rainfall: integer("rainfall"),
  forecast: text("forecast"), // JSON string
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  updatedAt: true,
});

export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type WeatherData = typeof weatherData.$inferSelect;

// Market Prices
export const marketPrices = pgTable("market_prices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cropName: text("crop_name").notNull(),
  variety: text("variety"),
  price: integer("price").notNull(), // in rupees per quintal
  unit: varchar("unit", { length: 20 }).notNull().default("quintal"),
  market: text("market").notNull(),
  state: text("state").notNull(),
  trend: varchar("trend", { length: 10 }), // 'up', 'down', 'stable'
  previousPrice: integer("previous_price"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMarketPriceSchema = createInsertSchema(marketPrices).omit({
  id: true,
  updatedAt: true,
});

export type InsertMarketPrice = z.infer<typeof insertMarketPriceSchema>;
export type MarketPrice = typeof marketPrices.$inferSelect;

// Advisory Tips
export const advisoryTips = pgTable("advisory_tips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: varchar("category", { length: 50 }).notNull(), // 'cultivation', 'fertilizer', 'pest-control', 'irrigation'
  title: text("title").notNull(),
  description: text("description").notNull(),
  cropType: text("crop_type"),
  season: varchar("season", { length: 20 }),
  language: varchar("language", { length: 10 }).notNull().default("en"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAdvisoryTipSchema = createInsertSchema(advisoryTips).omit({
  id: true,
  createdAt: true,
});

export type InsertAdvisoryTip = z.infer<typeof insertAdvisoryTipSchema>;
export type AdvisoryTip = typeof advisoryTips.$inferSelect;
