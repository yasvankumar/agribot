# AgriBot Design Guidelines

## Design Approach: Utility-First with Agricultural Context

**Selected Framework:** Material Design principles adapted for agricultural technology
**Rationale:** Farmers need clear, consistent, and accessible interfaces. Material Design provides proven patterns for information-dense applications while allowing customization for the agricultural domain.

**Key Design Principles:**
- Clarity over aesthetics - every element serves a functional purpose
- Accessibility for rural users with varying tech literacy
- Mobile-first responsive design
- Low cognitive load with familiar patterns
- Trust-building through professional, clean design

---

## Color Palette

### Light Mode
- **Primary:** 130 45% 45% (Earthy green representing agriculture/growth)
- **Primary Variant:** 130 50% 35% (Darker green for emphasis)
- **Secondary:** 35 60% 50% (Warm orange/amber for harvest/warmth)
- **Background:** 0 0% 98% (Off-white for reduced eye strain)
- **Surface:** 0 0% 100% (Pure white for cards/containers)
- **Text Primary:** 0 0% 13% (Near-black for readability)
- **Text Secondary:** 0 0% 40% (Gray for supporting text)
- **Success:** 140 60% 45% (Disease-free/healthy crops)
- **Warning:** 40 90% 50% (Moderate issues)
- **Error:** 0 70% 50% (Critical disease/pest alerts)

### Dark Mode
- **Primary:** 130 40% 60% (Lighter green for visibility)
- **Primary Variant:** 130 45% 50%
- **Secondary:** 35 70% 60%
- **Background:** 0 0% 10% (Dark background)
- **Surface:** 0 0% 15% (Elevated surfaces)
- **Text Primary:** 0 0% 95% (High contrast white)
- **Text Secondary:** 0 0% 70%

---

## Typography

**Font Stack:** 
- Primary: 'Inter' via Google Fonts (excellent readability, supports Tamil/Devanagari)
- Fallback: system-ui, sans-serif

**Type Scale:**
- Hero/H1: 2.5rem (40px) font-bold
- H2: 2rem (32px) font-semibold
- H3: 1.5rem (24px) font-semibold
- Body: 1rem (16px) font-normal (minimum for accessibility)
- Small: 0.875rem (14px) font-normal
- Caption: 0.75rem (12px) font-medium

**Bilingual Considerations:**
- Tamil text may need slightly larger sizing (1.05x multiplier)
- Ensure proper line-height (1.6) for Tamil script readability

---

## Layout System

**Spacing Scale:** Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing: p-2, m-2 (8px)
- Standard spacing: p-4, m-4 (16px)
- Component spacing: p-6, gap-6 (24px)
- Section spacing: p-8, py-12 (32px, 48px)
- Large gaps: gap-16 (64px)

**Grid System:**
- Mobile: Single column, full width with px-4 padding
- Tablet: 2-column layouts where appropriate
- Desktop: Max-width container (max-w-7xl), 2-3 column grids

**Container Strategy:**
- Chat interface: max-w-4xl centered for optimal reading
- Dashboard sections: max-w-7xl for wider layouts
- Forms: max-w-2xl for focused input

---

## Component Library

### Core Navigation
- **Top App Bar:** Sticky header with logo, language toggle (Tamil/English switch), user menu
- **Mobile Nav:** Hamburger menu with clear icons for: Chat, Disease Detection, Weather, Market Prices, Advisory Hub
- **Tab Navigation:** For switching between features within sections

### Chat Interface
- **Message Bubbles:** 
  - User messages: Aligned right, primary color background, white text
  - Bot messages: Aligned left, surface color (light gray), dark text
  - Rounded corners (rounded-2xl), max-width for readability
  - Timestamps in small, secondary text color
- **Input Area:** Fixed bottom bar with text input, send button, image upload button
- **Quick Actions:** Pill-shaped suggestion chips below input for common queries

### Disease Detection Module
- **Image Upload Card:** Large dashed border drop zone with camera/upload icons
- **Preview Area:** Uploaded image with crop/zoom controls
- **Results Card:** Disease name (bold, large), confidence score (percentage with color indicator), treatment recommendations in expandable sections
- **Similar Diseases:** Horizontal scroll of thumbnail cards

### Data Display Cards
- **Weather Card:** Icon (sun/cloud/rain), temperature (large), location, 3-day forecast mini-cards
- **Market Price Card:** Crop name, current price (prominent), trend indicator (up/down arrow), comparison to last week
- **Advisory Card:** Icon, title, brief description, expandable details

### Forms & Inputs
- **Text Inputs:** Outlined style, floating labels, clear focus states
- **Dropdowns:** Native select with custom styling for crop/region selection
- **Language Toggle:** Segmented control with clear labels (EN | தமிழ்)
- **Buttons:** 
  - Primary: Filled with primary color
  - Secondary: Outlined with primary color border
  - Text: For tertiary actions

### Feedback Elements
- **Loading States:** Skeleton screens for chat, spinner for image processing
- **Alerts:** Toast notifications for errors/success (top-right, auto-dismiss)
- **Empty States:** Friendly illustrations with helpful text

---

## Images

**Hero Section (Landing Page):**
- Large hero image: Indian farmer in field using smartphone, warm natural lighting, authentic representation
- Overlay: Semi-transparent gradient (bottom to top, dark to transparent) for text readability
- Placement: Full-width, 70vh height on desktop, 50vh on mobile

**Feature Sections:**
- Disease detection example: Close-up of diseased crop leaf with diagnostic overlay
- Chat interface preview: Screenshot showing bilingual conversation
- Market prices: Image of traditional mandi/market scene
- Weather advisory: Farmer checking crops under cloudy sky

**Dashboard Icons:**
- Use Heroicons for consistent, recognizable symbols
- Disease: beaker/microscope icon
- Weather: cloud-sun icon  
- Market: currency-rupee/trending-up icon
- Chat: chat-bubble icon
- Advisory: light-bulb/information-circle icon

---

## Accessibility & Performance

- **Contrast Ratios:** Minimum 4.5:1 for normal text, 3:1 for large text
- **Touch Targets:** Minimum 44x44px for all interactive elements
- **Focus Indicators:** Clear 2px outline in primary color
- **Image Optimization:** Lazy loading, WebP format with fallbacks
- **Offline Support:** Show clear messaging when connectivity is lost
- **Loading Performance:** Skeleton screens, progressive image loading

---

## Animations

**Minimal, Purposeful Motion:**
- Message appearance: Subtle fade-in + slide (100ms)
- Button interactions: Scale on press (95%)
- Card reveals: Stagger animation for lists (50ms delay)
- **Avoid:** Elaborate transitions, parallax effects, decorative animations

---

## Mobile-First Considerations

- Bottom navigation bar for primary features
- Swipe gestures for switching between chat history
- Large, thumb-friendly tap targets
- Collapsible sections to reduce scrolling
- Progressive disclosure for complex information
- Single-column layouts on mobile, multi-column on tablet+